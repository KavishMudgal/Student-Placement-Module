function closeWindow() {
            window.open('', '_self'); // needed for some browsers
            window.close();
        }