function status_view() {
    const block = document.querySelector(".status");

    // Show the block
    block.style.display = "block";
}
